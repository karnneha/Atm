# atm_locator/atm_locator/urls.py
from django.contrib import admin
from django.urls import path
from atm_app import views  # Import the views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', views.register, name='register'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('atms/', views.atm_list, name='atm_list'),  # Add this line for ATM list page
]
