from django.apps import AppConfig


class AtmAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'atm_app'
