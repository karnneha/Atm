import React from "react";

const Compare = () => {
  return <h1 className="text-center mt-10">Compare Colleges</h1>;
};

export default Compare;
