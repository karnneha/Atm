import React from "react";

const About = () => {
  return <h1 className="text-center mt-10">About Us</h1>;
};

export default About;
