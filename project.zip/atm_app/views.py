from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.views import LoginView, LogoutView
from .models import ATM  # Import your ATM model

# Registration view
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Auto-login after register
            return redirect('atm_list')  # Redirect to ATM list after registration
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

# Login view
class CustomLoginView(LoginView):
    template_name = 'registration/login.html'  # Correct path to login template

# Logout view
class CustomLogoutView(LogoutView):
    next_page = 'login'  # Redirect to login page after logout

# ATM list view (this is where the list of ATMs is shown)
def atm_list(request):
    atms = ATM.objects.all()  # Get all ATMs from the database
    return render(request, 'atm/atm_list.html', {'atms': atms})  # Corrected path
