# atm_locator/atm_app/models.py
from django.db import models

class ATM(models.Model):
    bank_name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    latitude = models.FloatField()
    longitude = models.FloatField()
    transaction_fee = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.bank_name
