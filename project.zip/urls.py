# atm_locator/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('atms/', include('atm_app.urls')),  # This line should correctly include atm_app URLs
    path('register/', include('django.contrib.auth.urls')),  # For authentication URLs
    path('login/', include('django.contrib.auth.urls')),
    path('logout/', include('django.contrib.auth.urls')),
]
