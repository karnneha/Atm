from django.db import models

class ATM(models.Model):
    bank_name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
    transaction_fee = models.DecimalField(max_digits=5, decimal_places=2)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, default=0.0)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, default=0.0)

    def __str__(self):
        return f"{self.bank_name} - {self.location}"
