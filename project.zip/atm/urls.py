from django.urls import path
from . import views

urlpatterns = [
    path('', views.atm_list, name='atm_list'),
    path('create/', views.atm_create, name='atm_create'),
    path('update/<int:pk>/', views.atm_update, name='atm_update'),
    path('delete/<int:pk>/', views.atm_delete, name='atm_delete'),
]

