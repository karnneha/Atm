from django import forms
from .models import ATM

class ATMForm(forms.ModelForm):
    class Meta:
        model = ATM
        fields = ['bank_name', 'location', 'transaction_fee', 'latitude', 'longitude']
